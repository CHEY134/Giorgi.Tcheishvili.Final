import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AnnouncementsComponent} from "./components/announcements/announcements.component";
import {AnnDetailsComponent} from "./components/ann-details/ann-details.component";

const routes: Routes = [
  { path: 'announcements', component: AnnouncementsComponent },
  { path: 'ann-details/:id', component: AnnDetailsComponent },
  { path: '', redirectTo: '/announcements', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
