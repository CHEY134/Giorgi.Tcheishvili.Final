export interface Announcement {
  id: number;
  title: string;
  customerName: string;
  isActive: boolean;
  deadlineDate: string;
}
