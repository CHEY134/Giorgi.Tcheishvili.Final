import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Announcement } from '../../models/announcement.model';
import { AnnouncementService } from '../../services/announcement.service';

@Component({
  selector: 'app-ann-details',
  templateUrl: './ann-details.component.html',
  styleUrls: ['./ann-details.component.css']
})
export class AnnDetailsComponent implements OnInit {
  announcement!: Announcement;

  constructor(
    private route: ActivatedRoute,
    private announcementService: AnnouncementService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.getAnnouncement();
  }

  getAnnouncement(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id !== null && id !== undefined) {
      this.announcementService.getAnnouncement(id)
        .subscribe(announcement => this.announcement = announcement);
    }
  }

  goBack(): void {
    this.location.back();
  }
}
