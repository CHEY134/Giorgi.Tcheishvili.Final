import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnDetailsComponent } from './ann-details.component';

describe('AnnDetailsComponent', () => {
  let component: AnnDetailsComponent;
  let fixture: ComponentFixture<AnnDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AnnDetailsComponent]
    });
    fixture = TestBed.createComponent(AnnDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
